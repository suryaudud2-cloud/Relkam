package com.example.rekam1080

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var mic: CheckBox
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "Rekam 1080p"; textSize = 26f })
        status = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)
        mic = CheckBox(this).apply { text = "Rekam mikrofon" }
        root.addView(mic)
        btn = Button(this).apply { setOnClickListener { toggle() } }
        root.addView(btn)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        RecorderService.listener = { render(it) }
        render(RecorderService.running)
    }

    override fun onPause() { RecorderService.listener = null; super.onPause() }

    private fun render(on: Boolean) {
        btn.text = if (on) "Berhenti" else "Mulai rekam"
        mic.isEnabled = !on
        status.text = if (on) "Sedang merekam. Hasil disimpan di Movies/Rekaman1080p."
        else "Sisi terpendek layar direkam di 1080 piksel."
    }

    private fun toggle() {
        if (RecorderService.running) { stopService(Intent(this, RecorderService::class.java)); return }
        val need = mutableListOf<String>()
        if (mic.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) askProjection() else requestPermissions(need.toTypedArray(), 2)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) mic.isChecked = false
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, RecorderService::class.java)
                .putExtra("code", res).putExtra("data", data).putExtra("mic", mic.isChecked))
        } else if (req == 1) Toast.makeText(this, "Izin rekam layar ditolak", Toast.LENGTH_SHORT).show()
    }
}
