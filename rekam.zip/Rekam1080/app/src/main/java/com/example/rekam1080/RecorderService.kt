package com.example.rekam1080

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class RecorderService : Service() {
    companion object {
        @Volatile var running = false
        var listener: ((Boolean) -> Unit)? = null
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var closing = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Perekaman layar", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rec")
            .setContentTitle("Merekam layar").setContentText("Buka aplikasi lalu tekan Berhenti")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>("data")
        try {
            begin(code, data!!, intent.getBooleanExtra("mic", false))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal merekam: ${e.message}", Toast.LENGTH_LONG).show()
            finish(); stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun begin(code: Int, data: Intent, mic: Boolean) {
        val m = DisplayMetrics()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        val scale = 1080f / minOf(m.widthPixels, m.heightPixels)
        val w = (m.widthPixels * scale).toInt() / 2 * 2
        val h = (m.heightPixels * scale).toInt() / 2 * 2

        val name = "Rekam1080p_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Rekaman1080p")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        pfd = contentResolver.openFileDescriptor(uri!!, "w")

        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        if (mic) r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        if (mic) { r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(128000); r.setAudioSamplingRate(44100) }
        r.setVideoSize(w, h); r.setVideoFrameRate(30); r.setVideoEncodingBitRate(10_000_000)
        r.setOutputFile(pfd!!.fileDescriptor)
        r.prepare()
        recorder = r

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))
        }
        display = projection!!.createVirtualDisplay("rec", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        r.start()
        running = true
        listener?.invoke(true)
    }

    private fun finish() {
        if (closing) return
        closing = true
        var ok = running
        try { recorder?.stop() } catch (e: RuntimeException) { ok = false }
        recorder?.release(); recorder = null
        display?.release(); display = null
        projection?.stop(); projection = null
        pfd?.close(); pfd = null
        uri?.let {
            if (ok) contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            else contentResolver.delete(it, null, null)
        }
        if (ok) Toast.makeText(this, "Rekaman disimpan di Movies/Rekaman1080p", Toast.LENGTH_LONG).show()
        running = false
        listener?.invoke(false)
    }

    override fun onDestroy() { finish(); super.onDestroy() }
}
